import { useRef, useState } from 'react';
import { formatFileSize } from '../utils/fileUtils';

function UploadPanel({ selectedFile, errorMessage, onFileSelect }) {
  const inputRef = useRef(null);
  const [isDragging, setIsDragging] = useState(false);

  const handleFiles = (files) => {
    const file = files?.[0];
    if (file) {
      onFileSelect(file);
    }
  };

  const handleDrop = (event) => {
    event.preventDefault();
    setIsDragging(false);
    handleFiles(event.dataTransfer.files);
  };

  return (
    <section className="upload-panel">
      <div
        className={`upload-dropzone ${isDragging ? 'is-dragging' : ''}`}
        onDragOver={(event) => {
          event.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleDrop}
      >
        <div className="upload-mark" aria-hidden="true">
          <svg width="34" height="34" viewBox="0 0 24 24" fill="none">
            <path
              d="M12 16V7M12 7l-3 3M12 7l3 3M5 16.5v.5A2 2 0 0 0 7 19h10a2 2 0 0 0 2-2v-.5"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </div>
        <h2>파일을 업로드하세요</h2>
        <p>PDF, DOCX 파일을 드래그하거나 클릭해 추가</p>
        <button
          type="button"
          className="primary-button"
          onClick={() => inputRef.current?.click()}
        >
          + 파일 선택
        </button>
        <input
          ref={inputRef}
          className="sr-only"
          type="file"
          accept=".pdf,.doc,.docx"
          onChange={(event) => {
            handleFiles(event.target.files);
            event.target.value = '';
          }}
        />

        {selectedFile ? (
          <div className="file-summary">
            <strong>{selectedFile.name}</strong>
            <span>{formatFileSize(selectedFile.size)}</span>
          </div>
        ) : null}

        <div className="secondary-meta">
          <span>모든 파일은 로컬에서 처리됩니다.</span>
          <span>데이터는 외부로 전송되지 않습니다.</span>
        </div>
      </div>

      {errorMessage ? (
        <div className="error-banner" role="alert">
          {errorMessage}
        </div>
      ) : null}
    </section>
  );
}

export default UploadPanel;
