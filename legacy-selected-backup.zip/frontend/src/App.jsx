import { useState } from 'react';
import Header from './components/Header';
import UploadPanel from './components/UploadPanel';
import FileSupportBar from './components/FileSupportBar';
import FeatureButtons from './components/FeatureButtons';
import PreviewInfoBox from './components/PreviewInfoBox';
import AssistantPanel from './components/AssistantPanel';
import PdfPreview from './components/PdfPreview';
import WordPreviewPlaceholder from './components/WordPreviewPlaceholder';
import { formatFileSize, validateFile } from './utils/fileUtils';

const INITIAL_MESSAGES = [
  {
    id: 'welcome-ai',
    role: 'assistant',
    text: '안녕하세요! 문서 검색, 요약, 수정 흐름을 준비하고 있습니다. 원하는 작업을 입력해 주세요.'
  },
  {
    id: 'sample-user',
    role: 'user',
    text: '프로젝트 일정이라는 내용을 찾아줘'
  },
  {
    id: 'sample-ai',
    role: 'assistant',
    text: '현재 AI 연동은 준비 중입니다. 다음 단계에서 실제 검색 결과와 연결할 예정입니다.'
  }
];

const FEATURE_MESSAGES = {
  search: '정확한 문서 검색 기능은 다음 단계에서 구현 예정입니다.',
  highlight: '위치 하이라이트 기능은 다음 단계에서 구현 예정입니다.',
  replace: '즉시 텍스트 교체 기능은 다음 단계에서 구현 예정입니다.'
};

function App() {
  const [selectedFile, setSelectedFile] = useState(null);
  const [errorMessage, setErrorMessage] = useState('');
  const [selectedFeature, setSelectedFeature] = useState('');
  const [chatMessages, setChatMessages] = useState(INITIAL_MESSAGES);

  const handleFileSelect = (file) => {
    if (!file) {
      return;
    }

    const validation = validateFile(file);
    if (!validation.valid) {
      setSelectedFile(null);
      setErrorMessage(validation.message);
      return;
    }

    setSelectedFile(file);
    setErrorMessage('');
  };

  const handleFeatureClick = (featureKey) => {
    setSelectedFeature(FEATURE_MESSAGES[featureKey] || '이 기능은 준비 중입니다.');
  };

  const handleSendMessage = (message) => {
    const trimmed = message.trim();
    if (!trimmed) {
      return;
    }

    setChatMessages((current) => [
      ...current,
      {
        id: `user-${Date.now()}`,
        role: 'user',
        text: trimmed
      },
      {
        id: `assistant-${Date.now() + 1}`,
        role: 'assistant',
        text: '현재 AI 연동은 준비 중입니다.'
      }
    ]);
  };

  const renderPreview = () => {
    if (!selectedFile) {
      return <PreviewInfoBox />;
    }

    if (selectedFile.name.toLowerCase().endsWith('.pdf')) {
      return <PdfPreview file={selectedFile} />;
    }

    return (
      <WordPreviewPlaceholder
        fileName={selectedFile.name}
        fileSize={formatFileSize(selectedFile.size)}
      />
    );
  };

  return (
    <div className="app-page">
      <div className="ambient ambient-left" />
      <div className="ambient ambient-right" />
      <div className="app-shell">
        <Header />
        <main className="main-layout">
          <section className="panel document-panel">
            <UploadPanel
              selectedFile={selectedFile}
              errorMessage={errorMessage}
              onFileSelect={handleFileSelect}
            />
            <FileSupportBar />
            <FeatureButtons onFeatureClick={handleFeatureClick} />
            <div className="preview-stage">
              {selectedFeature ? (
                <div className="inline-notice" role="status">
                  {selectedFeature}
                </div>
              ) : null}
              {renderPreview()}
            </div>
          </section>
          <AssistantPanel messages={chatMessages} onSendMessage={handleSendMessage} />
        </main>
      </div>
    </div>
  );
}

export default App;
