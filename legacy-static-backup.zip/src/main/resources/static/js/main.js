console.log('[JS 로드됨]');

const chatForm = typeof document !== 'undefined' ? document.getElementById('chatForm') : null;
const chatInput = typeof document !== 'undefined' ? document.getElementById('chatInput') : null;
const chatWindow = typeof document !== 'undefined' ? document.getElementById('chatWindow') : null;

export function resolvePdfViewerMode(userAgent = '', viewportWidth = 0) {
  const safeUserAgent = userAgent || (typeof navigator !== 'undefined' ? navigator.userAgent : '');
  const safeViewportWidth = viewportWidth || (typeof window !== 'undefined' ? window.innerWidth : 0);
  const isAndroid = /Android/i.test(safeUserAgent);
  const isSmallScreen = safeViewportWidth <= 768;
  return isAndroid || isSmallScreen ? 'pdfjs' : 'iframe';
}

function formatFileSize(bytes) {
  if (!bytes) return '';
  const kb = bytes / 1024;
  if (kb < 1024) return `${kb.toFixed(1)} KB`;
  return `${(kb / 1024).toFixed(1)} MB`;
}

function addMessage(text, isUser = false) {
  const row = document.createElement('div');
  row.className = `message ${isUser ? 'user' : 'ai'}`;
  const bubble = document.createElement('div');
  bubble.className = 'bubble';
  bubble.textContent = text;
  row.appendChild(bubble);
  chatWindow?.appendChild(row);
  if (chatWindow) {
    chatWindow.scrollTop = chatWindow.scrollHeight;
  }
}

function handleChatSubmit(event) {
  event.preventDefault();
  const value = chatInput?.value.trim();
  if (!value) return;

  addMessage(value, true);
  if (chatInput) {
    chatInput.value = '';
  }

  setTimeout(() => {
    addMessage('요청 내용을 확인했습니다. 테스트 화면에서는 실제 AI 응답 대신 이 메시지가 표시됩니다.', false);
  }, 350);
}

function initializeDocumentViewer() {
  const MAX_FILE_SIZE = 50 * 1024 * 1024;
  const previewArea = document.getElementById('documentPreviewArea') || document.getElementById('uploadBox');

  if (!previewArea) {
    console.warn('DocPilot 업로드 안내 영역을 찾을 수 없습니다.');
    return;
  }

  let fileInputRef = null;
  let debugMessages = [];
  let currentObjectUrl = null;
  let currentPdfDocument = null;
  let currentViewerType = null;

  appendDebugLog('[업로드 안내 영역 확인]');
  console.log('[uploadBox 확인]', previewArea);

  renderUploadPlaceholder();

  function renderUploadPlaceholder() {
    previewArea.innerHTML = `
      <div class="upload-card drop-zone" id="dropZone">
        <div class="upload-icon">📄</div>
        <h2 id="uploadTitle">파일을 업로드하세요</h2>
        <p id="uploadSubtitle">PDF, DOC, DOCX 파일을 드래그하거나 클릭해 추가</p>
        <button id="selectFileButton" type="button" class="upload-button select-file-button">
          ＋ 파일 선택
        </button>
        <input
          id="fileInput"
          name="file"
          type="file"
          accept=".pdf,.doc,.docx,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
          class="file-input-hidden"
        />
        <div id="debugLog" class="debug-log"></div>
        <div class="upload-meta" id="uploadMeta">
          <span>🔒 모든 파일은 로컬 환경에서 처리됩니다.</span>
          <span>데이터는 외부로 전송되지 않습니다.</span>
        </div>
      </div>`;

    renderDebugLog();
    bindUploadEvents();
  }

  function bindUploadEvents() {
    fileInputRef = previewArea.querySelector('#fileInput');
    const selectFileButton = previewArea.querySelector('#selectFileButton');
    const dropZone = previewArea.querySelector('#dropZone');

    if (selectFileButton && fileInputRef) {
      selectFileButton.addEventListener('click', (event) => {
        appendDebugLog('[파일선택 버튼 클릭됨]');
        event.preventDefault();
        fileInputRef.click();
      });
    }

    if (fileInputRef) {
      fileInputRef.addEventListener('change', async (event) => {
        appendDebugLog('[파일 선택 이벤트 발생]');
        const file = event.target.files?.[0];
        appendDebugLog(`[선택된 파일] ${file ? file.name : '없음'}`);
        if (!file) return;

        appendDebugLog(`[파일 타입] ${file.type || 'unknown'}`);
        appendDebugLog(`[파일 크기] ${formatFileSize(file.size)}`);
        event.target.value = '';
        await handleFileSelection(file);
      });
    }

    if (dropZone) {
      dropZone.addEventListener('dragover', (event) => {
        event.preventDefault();
        dropZone.classList.add('dragover');
      });

      dropZone.addEventListener('dragleave', () => {
        dropZone.classList.remove('dragover');
      });

      dropZone.addEventListener('drop', async (event) => {
        event.preventDefault();
        dropZone.classList.remove('dragover');
        const file = event.dataTransfer.files?.[0];
        if (file) {
          await handleFileSelection(file);
        }
      });
    }
  }

  async function handleFileSelection(file) {
    try {
      validateFile(file);
    } catch (error) {
      appendDebugLog(`[업로드 오류] ${error.message}`);
      return;
    }

    appendDebugLog('[업로드 안내 영역 확인]');
    if (isPdfFile(file)) {
      await showLocalViewer(file);
    } else {
      appendDebugLog('[지원하지 않는 형식이므로 기본 안내를 표시합니다.]');
      renderSelectionMessage(file);
    }
  }

  async function showLocalViewer(file) {
    const uploadBox = document.getElementById('uploadBox') || document.getElementById('documentPreviewArea');
    if (!uploadBox) {
      appendDebugLog('[오류] 업로드 안내 영역을 찾을 수 없음');
      return;
    }

    const fileName = file.name?.toLowerCase() || '';
    const isPdf = file.type === 'application/pdf' || fileName.endsWith('.pdf');
    const userAgent = navigator.userAgent || '';
    const isAndroid = /Android/i.test(userAgent);
    const isSmallScreen = window.innerWidth <= 768;
    const forcePdfJs = new URLSearchParams(window.location.search).get('viewer') === 'pdfjs';
    const viewerMode = isAndroid || isSmallScreen || forcePdfJs ? 'pdfjs' : 'iframe';

    appendDebugLog('[로컬 뷰어 표시 시작]');
    appendDebugLog(`[사용 브라우저] ${userAgent}`);
    appendDebugLog(`[isAndroid] ${isAndroid}`);
    appendDebugLog(`[isSmallScreen] ${isSmallScreen}`);
    appendDebugLog(`[forcePdfJs] ${forcePdfJs}`);
    appendDebugLog(`[viewerMode] ${viewerMode}`);

    if (!isPdf) {
      appendDebugLog('[지원하지 않는 형식이므로 기본 안내를 표시합니다.]');
      renderSelectionMessage(file);
      return;
    }

    clearViewerState();

    currentObjectUrl = URL.createObjectURL(file);
    appendDebugLog('[blob URL 생성]');
    appendDebugLog(`[blob URL] ${currentObjectUrl}`);

    if (viewerMode === 'pdfjs') {
      appendDebugLog('[선택된 뷰어 방식] PDF.js');
      await showPdfWithPdfJs(file, currentObjectUrl);
    } else {
      appendDebugLog('[선택된 뷰어 방식] iframe');
      await showPdfWithIframe(file, currentObjectUrl);
    }

    appendDebugLog('[로컬 PDF 뷰어 표시 완료]');
  }

  async function showPdfWithPdfJs(file, fileUrl) {
    appendDebugLog('[PDF.js 뷰어 표시 시작]');
    const uploadBox = document.getElementById('uploadBox') || document.getElementById('documentPreviewArea');
    const debugTextLayer = new URLSearchParams(window.location.search).get('debugTextLayer') === '1';

    if (!uploadBox) {
      appendDebugLog('[PDF.js 오류] uploadBox 없음');
      return;
    }

    appendDebugLog('[PDF.js 로드 확인]');
    const pdfLib = window.pdfjsLib;
    if (!pdfLib || typeof pdfLib.getDocument !== 'function') {
      appendDebugLog('[PDF.js 오류] getDocument 없음');
      appendDebugLog('[typeof window.pdfjsLib] ' + typeof window.pdfjsLib);
      appendDebugLog('[typeof pdfLib.getDocument] ' + typeof pdfLib?.getDocument);
      appendDebugLog('[PDF.js 오류] PDF.js 스크립트 로드 실패');
      uploadBox.innerHTML = `
        <div class="viewer-header">
          <div class="viewer-file-info">
            <span class="pdf-badge">PDF</span>
            <span class="viewer-file-name">${escapeHtml(file.name)}</span>
            <span class="viewer-file-size">${formatFileSize(file.size)}</span>
          </div>
          <button id="closeViewerBtn" type="button" class="viewer-close-btn">×</button>
        </div>
        <div class="viewer-error">
          <strong>PDF.js 로딩 실패</strong>
          <p>모바일 PDF 미리보기를 표시할 수 없습니다.</p>
          <p>PDF.js 스크립트 또는 worker 로드 상태를 확인하세요.</p>
        </div>
      `;
      uploadBox.querySelector('#closeViewerBtn')?.addEventListener('click', () => {
        closeViewer();
      });
      currentViewerType = 'pdfjs-error';
      return;
    }

    uploadBox.innerHTML = `
      <div class="viewer-header">
        <div class="viewer-file-info">
          <span class="pdf-badge">PDF</span>
          <span class="viewer-file-name">${escapeHtml(file.name)}</span>
          <span class="viewer-file-size">${formatFileSize(file.size)}</span>
        </div>
        <button id="closeViewerBtn" type="button" class="viewer-close-btn">×</button>
      </div>
      <div class="viewer-body pdfjs-viewer-body">
        <div id="pdfCanvasWrap" class="pdf-canvas-wrap"></div>
      </div>
      <div id="debugLog" class="debug-log"></div>`;

    renderDebugLog();
    uploadBox.querySelector('#closeViewerBtn')?.addEventListener('click', () => {
      closeViewer();
    });

    try {
      const pdfLib = window.pdfjsLib;
      appendDebugLog('[PDF.js version] ' + (pdfLib.version || 'unknown'));
      appendDebugLog('[debugTextLayer enabled] ' + debugTextLayer);
      const loadingTask = pdfLib.getDocument(fileUrl);
      const pdfDocument = await loadingTask.promise;
      currentPdfDocument = pdfDocument;
      appendDebugLog('[PDF.js 문서 로드 완료] pages=' + pdfDocument.numPages);

      const wrap = uploadBox.querySelector('#pdfCanvasWrap');
      if (!wrap) {
        throw new Error('PDF canvas 영역을 찾을 수 없습니다.');
      }

      wrap.innerHTML = '';
      appendDebugLog('[typeof pdfjsLib.renderTextLayer] ' + typeof pdfLib.renderTextLayer);
      if (debugTextLayer) {
        const selectionTest = document.createElement('div');
        selectionTest.className = 'text-select-test';
        selectionTest.textContent = '텍스트 선택 테스트 ABC 123';
        wrap.appendChild(selectionTest);
      }

      for (let pageNum = 1; pageNum <= pdfDocument.numPages; pageNum += 1) {
        const page = await pdfDocument.getPage(pageNum);
        if (pageNum === 1) {
          appendDebugLog('[PDF.js 첫 페이지 로드 완료]');
        }

        const pageElement = document.createElement('div');
        pageElement.className = 'pdf-page';

        const canvas = document.createElement('canvas');
        canvas.className = 'pdf-page-canvas';
        canvas.dataset.pageNumber = String(pageNum);

        const textLayer = document.createElement('div');
        textLayer.className = 'textLayer';
        textLayer.dataset.pageNumber = String(pageNum);
        if (debugTextLayer) {
          textLayer.classList.add('debug-text-layer');
        }

        pageElement.appendChild(canvas);
        pageElement.appendChild(textLayer);
        wrap.appendChild(pageElement);

        const context = canvas.getContext('2d');
        const viewport = page.getViewport({ scale: 1 });
        const wrapWidth = wrap.clientWidth || uploadBox.clientWidth || window.innerWidth;
        const scale = Math.max(0.8, Math.min(2.0, (wrapWidth - 24) / viewport.width));
        const scaledViewport = page.getViewport({ scale });
        const pageWidth = scaledViewport.width;
        const pageHeight = scaledViewport.height;
        const canvasWidth = Math.ceil(pageWidth);
        const canvasHeight = Math.ceil(pageHeight);

        pageElement.style.position = 'relative';
        pageElement.style.width = `${pageWidth}px`;
        pageElement.style.height = `${pageHeight}px`;

        canvas.width = canvasWidth;
        canvas.height = canvasHeight;
        canvas.style.width = `${pageWidth}px`;
        canvas.style.height = `${pageHeight}px`;

        textLayer.style.position = 'absolute';
        textLayer.style.left = '0';
        textLayer.style.top = '0';
        textLayer.style.width = `${pageWidth}px`;
        textLayer.style.height = `${pageHeight}px`;
        textLayer.style.setProperty('--scale-factor', String(scale));

        appendDebugLog('[pageDiv size] ' + pageElement.style.width + ' / ' + pageElement.style.height);
        appendDebugLog('[canvas size] ' + canvas.style.width + ' / ' + canvas.style.height);
        appendDebugLog('[textLayer size] ' + textLayer.style.width + ' / ' + textLayer.style.height);

        if (pageNum === 1) {
          appendDebugLog('[PDF.js scale 계산 완료] ' + scale);
          appendDebugLog('[canvas width] ' + canvas.width);
          appendDebugLog('[canvas height] ' + canvas.height);
        }

        await page.render({ canvasContext: context, viewport: scaledViewport }).promise;

        // Scanned/image-only PDFs may not contain text objects, so copy/select can still be unavailable.
        const textContent = await page.getTextContent();
        appendDebugLog('[textContent items] page ' + pageNum + ' = ' + textContent.items.length);
        if (textContent.items.length === 0) {
          appendDebugLog('[주의] 이 PDF는 텍스트 레이어가 없거나 스캔본일 수 있음');
        }
        if (typeof pdfLib.renderTextLayer !== 'function') {
          throw new Error('PDF.js textLayer 렌더러를 찾을 수 없습니다.');
        }

        const renderTextLayer = async (renderParams) => {
          textLayer.replaceChildren();
          let task;
          try {
            task = pdfLib.renderTextLayer(renderParams);
          } catch (renderError) {
            appendDebugLog('[renderTextLayer 호출 오류] ' + renderError.message);
            throw renderError;
          }
          if (task?.promise) {
            try {
              await task.promise;
            } catch (renderPromiseError) {
              appendDebugLog('[renderTextLayer promise 오류] ' + renderPromiseError.message);
              throw renderPromiseError;
            }
          }
          return task;
        };

        appendDebugLog('[renderTextLayer 시도] page ' + pageNum + ' = textContentSource');
        await renderTextLayer({
          textContentSource: textContent,
          container: textLayer,
          viewport: scaledViewport,
          textDivs: []
        });

        let textSpanCount = textLayer.querySelectorAll('span').length;
        if (textSpanCount === 0 && textContent.items.length > 0) {
          appendDebugLog('[textLayer fallback] textContent 파라미터로 재시도');
          await renderTextLayer({
            textContent,
            container: textLayer,
            viewport: scaledViewport,
            textDivs: []
          });
          textSpanCount = textLayer.querySelectorAll('span').length;
        }

        const markedContentCount = textLayer.querySelectorAll('.markedContent').length;
        const endOfContentCount = textLayer.querySelectorAll('.endOfContent').length;
        appendDebugLog('[textLayer span 개수] page ' + pageNum + ' = ' + textSpanCount);
        appendDebugLog('[textLayer markedContent 개수] page ' + pageNum + ' = ' + markedContentCount);
        appendDebugLog('[textLayer endOfContent 개수] page ' + pageNum + ' = ' + endOfContentCount);

        appendDebugLog('[PDF.js 페이지 렌더링 완료] ' + pageNum + '/' + pdfDocument.numPages);
      }

      appendDebugLog('[PDF.js 렌더링 완료]');
    } catch (error) {
      appendDebugLog(`[PDF.js 오류] ${error.message}`);
      uploadBox.innerHTML = `
        <div class="viewer-header">
          <div class="viewer-file-info">
            <span class="pdf-badge">PDF</span>
            <span class="viewer-file-name">${escapeHtml(file.name)}</span>
            <span class="viewer-file-size">${formatFileSize(file.size)}</span>
          </div>
          <button id="closeViewerBtn" type="button" class="viewer-close-btn">×</button>
        </div>
        <div class="viewer-error">
          <strong>PDF 렌더링 실패</strong>
          <p>${escapeHtml(error.message)}</p>
        </div>
      `;
      uploadBox.querySelector('#closeViewerBtn')?.addEventListener('click', () => {
        closeViewer();
      });
      currentViewerType = 'pdfjs-error';
      return;
    }

    debugViewerMetrics();
    currentViewerType = 'pdfjs';
  }

  async function showPdfWithIframe(file, fileUrl) {
    appendDebugLog('[iframe 뷰어 표시 시작]');
    const uploadBox = document.getElementById('uploadBox') || document.getElementById('documentPreviewArea');

    if (!uploadBox) {
      appendDebugLog('[오류] 업로드 안내 영역을 찾을 수 없음');
      return;
    }

    uploadBox.innerHTML = `
      <div class="viewer-header">
        <div class="viewer-file-info">
          <span class="pdf-badge">PDF</span>
          <span class="viewer-file-name">${escapeHtml(file.name)}</span>
          <span class="viewer-file-size">${formatFileSize(file.size)}</span>
        </div>
        <button id="closeViewerBtn" type="button" class="viewer-close-btn">×</button>
      </div>
      <div class="viewer-body iframe-viewer-body">
        <iframe class="pdf-viewer" src="${fileUrl}" title="${escapeHtml(file.name)}"></iframe>
      </div>
      <div id="debugLog" class="debug-log"></div>`;

    renderDebugLog();
    uploadBox.querySelector('#closeViewerBtn')?.addEventListener('click', () => {
      closeViewer();
    });

    debugViewerMetrics();
    currentViewerType = 'iframe';
  }

  function renderSelectionMessage(file) {
    previewArea.innerHTML = `
      <div class="selection-info-card">
        <div class="selection-info-title">선택된 파일</div>
        <div class="selection-info-name">${escapeHtml(file.name)}</div>
        <div class="selection-info-size">${formatFileSize(file.size)}</div>
        <p class="selection-info-note">현재는 PDF 파일 미리보기를 기본으로 제공합니다.</p>
        <button id="reselectFileButton" type="button" class="reselect-button">다른 파일 선택</button>
        <div id="debugLog" class="debug-log"></div>
      </div>`;

    renderDebugLog();
    previewArea.querySelector('#reselectFileButton')?.addEventListener('click', () => {
      appendDebugLog('[파일선택 버튼 클릭됨]');
      fileInputRef?.click();
    });
  }

  function validateFile(file) {
    const extension = getExtension(file.name);
    const allowedTypes = [
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    ];

    if (!['pdf', 'doc', 'docx'].includes(extension)) {
      throw new Error('PDF 또는 DOC/DOCX 파일만 선택할 수 있습니다.');
    }
    if (!allowedTypes.includes(file.type) && file.type !== '') {
      throw new Error('PDF 또는 DOC/DOCX 파일만 선택할 수 있습니다.');
    }
    if (file.size === 0) {
      throw new Error('내용이 없는 파일입니다.');
    }
    if (file.size > MAX_FILE_SIZE) {
      throw new Error('파일 크기는 50MB를 초과할 수 없습니다.');
    }
  }

  function closeViewer() {
    appendDebugLog('[뷰어 닫기]');
    clearViewerState();

    if (fileInputRef) {
      fileInputRef.value = '';
    }

    renderUploadPlaceholder();
  }

  function clearViewerState() {
    if (currentObjectUrl) {
      URL.revokeObjectURL(currentObjectUrl);
      currentObjectUrl = null;
    }

    if (currentPdfDocument) {
      currentPdfDocument.destroy?.();
      currentPdfDocument = null;
    }

    currentViewerType = null;
  }

  function isPdfFile(file) {
    const fileName = file.name?.toLowerCase() || '';
    return file.type === 'application/pdf' || fileName.endsWith('.pdf');
  }

  function getExtension(fileName) {
    const parts = fileName.toLowerCase().split('.');
    return parts.length > 1 ? parts.pop() : '';
  }

  function appendDebugLog(message) {
    debugMessages.push(message);
    console.log(message);
    renderDebugLog();
  }

  function debugViewerMetrics() {
    const viewerBody = previewArea.querySelector('.viewer-body, .pdfjs-viewer-body');
    const pdfViewer = previewArea.querySelector('.pdf-viewer, #pdfCanvas');
    const parentContainer = previewArea.parentElement;

    appendDebugLog(`[uploadBox 높이] ${Math.round(previewArea.getBoundingClientRect().height)}`);
    appendDebugLog(`[viewer-body 높이] ${Math.round(viewerBody?.getBoundingClientRect().height || 0)}`);
    appendDebugLog(`[pdf-viewer 높이] ${Math.round(pdfViewer?.getBoundingClientRect().height || 0)}`);
    appendDebugLog(`[부모 컨테이너 높이] ${Math.round(parentContainer?.getBoundingClientRect().height || 0)}`);
  }

  function renderDebugLog() {
    const debugLog = previewArea.querySelector('#debugLog');
    if (!debugLog) {
      return;
    }

    debugLog.innerHTML = debugMessages
      .map((message) => `<div class="debug-log-entry">${escapeHtml(message)}</div>`)
      .join('');
    debugLog.scrollTop = debugLog.scrollHeight;
  }

  function escapeHtml(value) {
    return String(value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }
}

if (typeof document !== 'undefined') {
  document.addEventListener('DOMContentLoaded', () => {
    initializeDocumentViewer();
    console.log('DocPilot document viewer initialized');
    if (chatForm) {
      chatForm.addEventListener('submit', handleChatSubmit);
    }
  });
}
