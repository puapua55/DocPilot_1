const ALLOWED_EXTENSIONS = ['pdf', 'doc', 'docx'];
const MAX_FILE_SIZE = 50 * 1024 * 1024;

export function getFileExtension(fileName = '') {
  const parts = fileName.split('.');
  return parts.length > 1 ? parts.pop().toLowerCase() : '';
}

export function formatFileSize(bytes = 0) {
  if (bytes <= 0) {
    return '0 B';
  }

  const units = ['B', 'KB', 'MB', 'GB'];
  let value = bytes;
  let unitIndex = 0;

  while (value >= 1024 && unitIndex < units.length - 1) {
    value /= 1024;
    unitIndex += 1;
  }

  return `${value.toFixed(unitIndex === 0 ? 0 : 1)} ${units[unitIndex]}`;
}

export function validateFile(file) {
  if (!file) {
    return { valid: false, message: '파일을 선택해 주세요.' };
  }

  const extension = getFileExtension(file.name);
  if (!ALLOWED_EXTENSIONS.includes(extension)) {
    return {
      valid: false,
      message: '지원하지 않는 파일 형식입니다. PDF, DOC, DOCX 파일만 업로드할 수 있습니다.'
    };
  }

  if (file.size <= 0) {
    return {
      valid: false,
      message: '0 byte 파일은 업로드할 수 없습니다.'
    };
  }

  if (file.size > MAX_FILE_SIZE) {
    return {
      valid: false,
      message: '파일 크기는 50MB 이하만 허용됩니다.'
    };
  }

  return { valid: true, message: '' };
}

export { ALLOWED_EXTENSIONS, MAX_FILE_SIZE };
